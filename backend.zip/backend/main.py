from fastapi import (
    FastAPI,
    Query,
    HTTPException,
    WebSocket,
    WebSocketDisconnect,
    Request,
)


from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os
import json
import requests
import secrets
import sys
from datetime import datetime
import asyncio
import smtplib
from email.mime.text import MIMEText

# Optional Supabase integration
from dotenv import load_dotenv

try:
    from supabase import create_client
except Exception:
    create_client = None

load_dotenv()
SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")
if SUPABASE_URL and SUPABASE_KEY and create_client:
    try:
        supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
        print("[DEBUG] Supabase client initialized")
    except Exception as e:
        supabase = None
        print(f"[DEBUG] Failed to initialize Supabase client: {e}")
else:
    supabase = None

# --------------------------------
# CONFIG
# --------------------------------
BASE_WORKSPACE = "workspace"
USERS_DB = "users_db.json"
TEAMS_DB = "teams_db.json"
FILE_VERSIONS_DB = "file_versions_db.json"
WORKSPACE_CODES_DB = "workspace_codes.json"
MEETINGS_DB = "meetings_db.json"

os.makedirs(BASE_WORKSPACE, exist_ok=True)


def normalize_file_key(path: str) -> str:
    """Normalize file key to use forward slashes for consistency across platforms"""
    return path.replace("\\", "/")


# create FastAPI application and wire up middleware
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------------------------
# MODELS
# --------------------------------
class FileUpdate(BaseModel):
    content: str


class UserLogin(BaseModel):
    email: str
    password: str


class UserSignup(BaseModel):
    email: str
    password: str


class Message(BaseModel):
    role: str
    content: str


class AIRequest(BaseModel):
    # default model should match what the Ollama server actually provides; the
    # workspace typically uses the latest LLaMA 3 model.  llama3 is just a
    # shorthand that many clients send, but the local Ollama instance might
    # expose names such as "llama3.2:latest" or "llama3.2:1b".  Use the latest
    # variant by default so simple requests (and the example client) work out
    # of the box.
    model: str = "llama3.2:latest"
    prompt: str = None
    messages: list = None


class JoinTeamRequest(BaseModel):
    invitation_key: str
    member_email: str


class MeetingSchedule(BaseModel):
    workspace: str
    time: str  # ISO date/time or simple string
    link: str = None  # optional Google Meet link supplied by user


# --------------------------------
# HELPERS
# --------------------------------


def load_users_db():
    """Load users database"""
    # Try Supabase kv_store first
    if supabase:
        try:
            res = (
                supabase.table("kv_store")
                .select("value")
                .eq("key", "users_db")
                .execute()
            )
            if res and res.data:
                return res.data[0].get("value") or {}
        except Exception as e:
            print(f"[DEBUG] Supabase load_users_db failed: {e}")

    if os.path.exists(USERS_DB):
        with open(USERS_DB, "r") as f:
            return json.load(f)
    return {}


def save_users_db(users):
    """Save users database"""
    # Try to save to Supabase kv_store
    if supabase:
        try:
            supabase.table("kv_store").upsert(
                {"key": "users_db", "value": users}
            ).execute()
        except Exception as e:
            print(f"[DEBUG] Supabase save_users_db failed: {e}")

    with open(USERS_DB, "w") as f:
        json.dump(users, f)


def load_teams_db():
    """Load teams database with invitation keys"""
    if supabase:
        try:
            res = (
                supabase.table("kv_store")
                .select("value")
                .eq("key", "teams_db")
                .execute()
            )
            if res and res.data:
                return res.data[0].get("value") or {}
        except Exception as e:
            print(f"[DEBUG] Supabase load_teams_db failed: {e}")

    if os.path.exists(TEAMS_DB):
        with open(TEAMS_DB, "r") as f:
            return json.load(f)
    return {}


def save_teams_db(teams):
    """Save teams database"""
    if supabase:
        try:
            supabase.table("kv_store").upsert(
                {"key": "teams_db", "value": teams}
            ).execute()
        except Exception as e:
            print(f"[DEBUG] Supabase save_teams_db failed: {e}")

    with open(TEAMS_DB, "w") as f:
        json.dump(teams, f, indent=2)


def load_meetings_db():
    """Load scheduled meetings database"""
    if os.path.exists(MEETINGS_DB):
        with open(MEETINGS_DB, "r") as f:
            return json.load(f)
    return []


def save_meetings_db(meetings):
    """Save scheduled meetings database"""
    with open(MEETINGS_DB, "w") as f:
        json.dump(meetings, f, indent=2)


def load_file_versions():
    """Load file versions metadata"""
    if supabase:
        try:
            res = (
                supabase.table("kv_store")
                .select("value")
                .eq("key", "file_versions_db")
                .execute()
            )
            if res and res.data:
                return res.data[0].get("value") or {}
        except Exception as e:
            print(f"[DEBUG] Supabase load_file_versions failed: {e}")

    if os.path.exists(FILE_VERSIONS_DB):
        with open(FILE_VERSIONS_DB, "r") as f:
            return json.load(f)
    return {}


def save_file_versions(versions):
    """Save file versions metadata"""
    if supabase:
        try:
            supabase.table("kv_store").upsert(
                {"key": "file_versions_db", "value": versions}
            ).execute()
        except Exception as e:
            print(f"[DEBUG] Supabase save_file_versions failed: {e}")

    with open(FILE_VERSIONS_DB, "w") as f:
        json.dump(versions, f, indent=2)


def load_workspace_codes():
    """Load workspace codes database"""
    if supabase:
        try:
            res = (
                supabase.table("kv_store")
                .select("value")
                .eq("key", "workspace_codes_db")
                .execute()
            )
            if res and res.data:
                return res.data[0].get("value") or {}
        except Exception as e:
            print(f"[DEBUG] Supabase load_workspace_codes failed: {e}")

    if os.path.exists(WORKSPACE_CODES_DB):
        with open(WORKSPACE_CODES_DB, "r") as f:
            return json.load(f)
    return {}


def save_workspace_codes(codes):
    """Save workspace codes database"""
    if supabase:
        try:
            supabase.table("kv_store").upsert(
                {"key": "workspace_codes_db", "value": codes}
            ).execute()
        except Exception as e:
            print(f"[DEBUG] Supabase save_workspace_codes failed: {e}")

    with open(WORKSPACE_CODES_DB, "w") as f:
        json.dump(codes, f, indent=2)


def get_or_create_workspace_code(email: str) -> str:
    """Get existing or create new unique workspace code for email"""
    codes = load_workspace_codes()
    if email in codes:
        return codes[email]

    # Generate unique 8-digit code
    code = secrets.token_hex(4).upper()  # 8 character hex string
    codes[email] = code
    save_workspace_codes(codes)
    return code


def load_projects_db():
    """Load projects database"""
    PROJECTS_DB = "projects_db.json"
    # Try Supabase kv_store first
    if supabase:
        try:
            res = (
                supabase.table("kv_store")
                .select("value")
                .eq("key", "projects_db")
                .execute()
            )
            if res and res.data:
                return res.data[0].get("value") or {}
        except Exception as e:
            print(f"[DEBUG] Supabase load_projects_db failed: {e}")

    if not os.path.exists(PROJECTS_DB):
        return {}
    try:
        with open(PROJECTS_DB, "r") as f:
            return json.load(f)
    except:
        return {}


def save_projects_db(data):
    """Save projects database"""
    PROJECTS_DB = "projects_db.json"
    if supabase:
        try:
            supabase.table("kv_store").upsert(
                {"key": "projects_db", "value": data}
            ).execute()
        except Exception as e:
            print(f"[DEBUG] Supabase save_projects_db failed: {e}")

    with open(PROJECTS_DB, "w") as f:
        json.dump(data, f, indent=2)


# --------------------------------
# WEBSOCKET CONNECTION MANAGER
# --------------------------------
class ConnectionManager:
    def __init__(self):
        # workspace -> list of (websocket, user)
        self.connections = {}
        self.lock = asyncio.Lock()

    async def connect(self, workspace: str, user: str, websocket: WebSocket):
        await websocket.accept()
        async with self.lock:
            if workspace not in self.connections:
                self.connections[workspace] = []
            self.connections[workspace].append((websocket, user))
        # broadcast updated members to workspace
        await self.broadcast_members(workspace)

    async def disconnect(self, websocket: WebSocket):
        async with self.lock:
            for workspace, conns in list(self.connections.items()):
                for idx, (ws, user) in enumerate(conns):
                    if ws is websocket:
                        conns.pop(idx)
                        break
                if not conns:
                    del self.connections[workspace]

    async def send_personal(self, websocket: WebSocket, message: str):
        await websocket.send_text(message)

    async def broadcast(self, workspace: str, message: str):
        async with self.lock:
            conns = list(self.connections.get(workspace, []))
        for ws, _ in conns:
            try:
                await ws.send_text(message)
            except:
                # ignore send errors; disconnect will clean up
                pass

    async def broadcast_members(self, workspace: str):
        # Build current members list from teams DB + owner
        teams = load_teams_db()
        members = []
        owner = workspace
        if workspace in teams:
            members = teams[workspace].get("members", [])[:]

        # Get list of currently connected users
        connected = [user for ws, user in self.connections.get(workspace, [])]

        payload = json.dumps(
            {
                "type": "members",
                "workspace": workspace,
                "owner": owner,
                "members": members,
                "connected": connected,
            }
        )
        await self.broadcast(workspace, payload)

    async def broadcast_chat(self, workspace: str, sender: str, text: str):
        msg = json.dumps(
            {
                "type": "chat",
                "workspace": workspace,
                "sender": sender,
                "text": text,
                "ts": datetime.now().isoformat(),
            }
        )
        await self.broadcast(workspace, msg)

    async def broadcast_projects(self, workspace: str):
        """Broadcast project updates to all team members"""
        projects = load_projects_db()
        workspace_projects = projects.get(workspace, [])
        msg = json.dumps(
            {
                "type": "projects_update",
                "workspace": workspace,
                "projects": workspace_projects,
                "ts": datetime.now().isoformat(),
            }
        )
        await self.broadcast(workspace, msg)


manager = ConnectionManager()


def get_or_create_version_entry(file_path: str) -> dict:
    """Get or create version entry for a file"""
    versions = load_file_versions()
    if file_path not in versions:
        versions[file_path] = {
            "created": datetime.now().isoformat(),
            "modified": datetime.now().isoformat(),
            "versions": [],
        }
        save_file_versions(versions)
    return versions[file_path]


def update_file_version(file_path: str, content: str):
    """Add a new version entry for a file"""
    versions = load_file_versions()
    if file_path not in versions:
        versions[file_path] = {
            "created": datetime.now().isoformat(),
            "modified": datetime.now().isoformat(),
            "versions": [],
        }

    versions[file_path]["modified"] = datetime.now().isoformat()
    versions[file_path]["versions"].append(
        {"timestamp": datetime.now().isoformat(), "size": len(content)}
    )
    save_file_versions(versions)


def generate_invitation_key():
    """Generate a unique 8-character invitation key"""
    return secrets.token_hex(4).upper()


def generate_google_meet_link():
    """Produce a pseudo-random Google Meet URL (format xxx-xxx-xxx)"""
    parts = [
        "".join(secrets.choice("abcdefghijklmnopqrstuvwxyz") for _ in range(3))
        for _ in range(3)
    ]
    return f"https://meet.google.com/{parts[0]}-{parts[1]}-{parts[2]}"


def send_email(to_email: str, subject: str, body: str) -> bool:
    """Send a simple plain-text email using SMTP settings from environment.

    Required env vars: EMAIL_HOST, EMAIL_PORT, EMAIL_USER, EMAIL_PASS
    Optional: EMAIL_USE_TLS (1/0, defaults to 1)
    If configuration is missing the function logs and returns False without error.
    """
    host = os.environ.get("EMAIL_HOST")
    if not host:
        print(f"[DEBUG] email host not configured, skipping send to {to_email}")
        return False
    port = int(os.environ.get("EMAIL_PORT", "587"))
    user = os.environ.get("EMAIL_USER")
    pwd = os.environ.get("EMAIL_PASS")
    use_tls = os.environ.get("EMAIL_USE_TLS", "1") == "1"

    if not user or not pwd:
        print(f"[DEBUG] email credentials not configured, skipping send to {to_email}")
        return False

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = to_email
    try:
        server = smtplib.SMTP(host, port, timeout=10)
        if use_tls:
            server.starttls()
        server.login(user, pwd)
        server.send_message(msg)
        server.quit()
        print(f"[DEBUG] sent email to {to_email}")
        return True
    except Exception as e:
        print(f"[DEBUG] failed to send email to {to_email}: {e}")
        return False


def save_users_db(users):
    """Save users database"""
    with open(USERS_DB, "w") as f:
        json.dump(users, f)


def safe_path(path: str, user_email: str = None) -> str:
    """Prevent path traversal - organize by user email if provided"""
    # If user_email is provided, organize workspace by email
    if user_email:
        base = os.path.join(BASE_WORKSPACE, user_email)
    else:
        base = BASE_WORKSPACE

    os.makedirs(base, exist_ok=True)

    # join with base and resolve to absolute normalized path
    joined = os.path.join(base, path or "")
    full_path = os.path.abspath(os.path.normpath(joined))
    base_abs = os.path.abspath(base)
    # allow the base directory itself, or any path under it
    if not (full_path == base_abs or full_path.startswith(base_abs + os.sep)):
        raise ValueError("Invalid path")
    return full_path


# --------------------------------
# ROUTES
# --------------------------------


@app.post("/signup")
def signup(user: UserSignup):
    """Register a new user"""
    email = user.email.strip().lower()
    password = user.password.strip()

    if not email or not password:
        raise HTTPException(status_code=400, detail="Email and password required")

    users = load_users_db()

    if email in users:
        raise HTTPException(status_code=400, detail="Email already registered")

    users[email] = {"password": password}
    save_users_db(users)

    # Create user workspace directory
    user_workspace = os.path.join(BASE_WORKSPACE, email)
    os.makedirs(user_workspace, exist_ok=True)

    return {"ok": True, "message": "User created successfully", "email": email}


@app.post("/login")
def login(user: UserLogin):
    """Login user"""
    email = user.email.strip().lower()
    password = user.password.strip()

    if not email or not password:
        raise HTTPException(status_code=400, detail="Email and password required")

    users = load_users_db()

    if email not in users:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    if users[email]["password"] != password:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    return {"ok": True, "message": "Login successful", "email": email}


@app.get("/items")
def list_items(
    email: str = Query(...), path: str = Query(None), viewer: str = Query(None)
):
    """List items in a user's workspace or within a specific folder path.

    If `viewer` is provided and is a member (joined via code) viewing another user's workspace,
    only files created by the workspace owner will be shown to that viewer. Owners see all files.
    """
    email = email.strip().lower()
    viewer = (viewer or "").strip().lower() or None
    items = []
    try:
        target = path or ""
        base = safe_path(target, email)
        if os.path.exists(base):
            versions = load_file_versions()
            teams = load_teams_db()

            # determine if viewer is a joined member of this workspace
            is_joined_member = False
            if viewer and email in teams and viewer in teams[email].get("members", []):
                is_joined_member = True

            for item in os.listdir(base):
                item_path = os.path.join(base, item)
                rel_key = normalize_file_key(os.path.relpath(item_path, BASE_WORKSPACE))

                if os.path.isdir(item_path):
                    items.append({"type": "folder", "name": item})
                else:
                    # default include
                    include = True

                    # if viewer is a joined member and NOT the owner, show files created by owner OR by any team member
                    if is_joined_member and viewer != email:
                        meta = versions.get(rel_key)
                        if meta:
                            created_by = meta.get("created_by")
                            # allow if created by owner or by a team member of this workspace
                            members_list = teams.get(email, {}).get("members", [])
                            if created_by != email and created_by not in members_list:
                                include = False
                        else:
                            # no metadata -> conservatively hide for joined members
                            include = False

                    if include:
                        items.append({"type": "file", "name": item})
    except Exception as e:
        print(f"Error listing items: {e}")
    return {"items": items}


@app.post("/folder")
def create_folder(
    name: str = Query(...), email: str = Query(...), actor: str = Query(None)
):
    """Create a new folder for a workspace. `email` is the workspace owner,
    `actor` is the user performing the action (may be the owner or a member).
    """
    email = email.strip().lower()
    actor = (actor or email).strip().lower()
    folder_path = safe_path(name, email)
    os.makedirs(folder_path, exist_ok=True)

    # Track folder metadata
    versions = load_file_versions()
    folder_key = normalize_file_key(os.path.relpath(folder_path, BASE_WORKSPACE))
    if folder_key not in versions:
        versions[folder_key] = {
            "type": "folder",
            "created": datetime.now().isoformat(),
            "created_by": actor,
        }
        save_file_versions(versions)

    print(f"Created folder for {email} by {actor}: {folder_path}")
    # notify workspace members about folder change
    try:
        asyncio.create_task(
            manager.broadcast(
                email,
                json.dumps(
                    {
                        "type": "files",
                        "action": "created",
                        "path": folder_key,
                        "actor": actor,
                    }
                ),
            )
        )
    except Exception:
        pass

    return {"ok": True, "message": "Folder created successfully"}


@app.post("/file")
def create_file(
    name: str = Query(...), email: str = Query(...), actor: str = Query(None)
):
    """Create a new file for a workspace. `email` is workspace owner; `actor` is actual user creating the file."""
    email = email.strip().lower()
    actor = (actor or email).strip().lower()
    file_path = safe_path(name, email)
    os.makedirs(os.path.dirname(file_path), exist_ok=True)

    if not os.path.exists(file_path):
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("")

        # Track file creation
        versions = load_file_versions()
        file_key = normalize_file_key(os.path.relpath(file_path, BASE_WORKSPACE))
        versions[file_key] = {
            "type": "file",
            "created": datetime.now().isoformat(),
            "created_by": actor,
            "modified": datetime.now().isoformat(),
            "versions": [
                {
                    "timestamp": datetime.now().isoformat(),
                    "size": 0,
                    "modified_by": actor,
                }
            ],
        }
        save_file_versions(versions)

    print(f"Created file for workspace {email} by {actor}: {file_path}")
    # notify workspace members about new file
    try:
        asyncio.create_task(
            manager.broadcast(
                email,
                json.dumps(
                    {
                        "type": "files",
                        "action": "created",
                        "path": file_key,
                        "actor": actor,
                    }
                ),
            )
        )
    except Exception:
        pass

    return {"ok": True, "message": "File created successfully"}


@app.delete("/file/{path:path}")
def delete_file(path: str, email: str = Query(...), actor: str = Query(None)):
    """Delete a file for a given workspace. Only the file creator can delete it.

    Args:
        email: workspace owner
        actor: the person deleting the file (must be the file creator)
    """
    email = email.strip().lower()
    actor = (actor or email).strip().lower()
    file_path = safe_path(path, email)

    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    # ensure it's a file (do not delete directories here)
    if os.path.isdir(file_path):
        raise HTTPException(status_code=400, detail="Path is a directory")

    # Only allow delete if actor is the file creator
    versions = load_file_versions()
    file_key = normalize_file_key(os.path.relpath(file_path, BASE_WORKSPACE))
    meta = versions.get(file_key)
    if meta:
        created_by = meta.get("created_by")
        if actor != created_by:
            raise HTTPException(
                status_code=403, detail="Only the file creator can delete this file"
            )
    else:
        # no metadata - conservatively block deletion
        raise HTTPException(
            status_code=403, detail="Cannot delete file without metadata"
        )

    try:
        os.remove(file_path)
        print(f"Deleted file for {email} by {actor}: {file_path}")
        # notify members about deletion
        try:
            broadcast_msg = {
                "type": "files",
                "action": "deleted",
                "path": file_key,
                "actor": actor,
            }
            print(f"Broadcasting deletion to workspace {email}: {broadcast_msg}")
            asyncio.create_task(manager.broadcast(email, json.dumps(broadcast_msg)))
        except Exception as e:
            print(f"Error broadcasting deletion: {e}")

        return {"ok": True, "message": "File deleted"}
    except Exception as e:
        print(f"Error deleting file: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete file")


@app.get("/file/versions/{path:path}")
def get_file_versions(path: str, email: str = Query(...)):
    """Get version history for a file"""
    email = email.strip().lower()
    versions = load_file_versions()

    # Normalize the file key to use forward slashes
    file_key = normalize_file_key(os.path.join(email, path))

    print(f"Looking for file_key: {file_key}")
    print(
        f"Available keys with email: {[k for k in versions.keys() if email in k][:5]}"
    )

    if file_key in versions:
        print(f"Found version history for {file_key}")
        # Don't send full content in version history to save bandwidth
        version_data = versions[file_key].copy()
        # Remove content from versions list in response
        if "versions" in version_data:
            clean_versions = []
            for v in version_data["versions"]:
                clean_v = {k: val for k, val in v.items() if k != "content"}
                clean_versions.append(clean_v)
            version_data["versions"] = clean_versions

        return {"ok": True, "file": file_key, "versions": version_data}
    else:
        print(f"Version history NOT found for {file_key}")

    return {"ok": True, "file": file_key, "versions": None}


@app.get("/file/{path:path}")
def open_file(path: str, email: str = Query(...), viewer: str = Query(None)):
    email = email.strip().lower()
    viewer = (viewer or "").strip().lower() or None
    file_path = safe_path(path, email)

    if not os.path.exists(file_path):
        return {"content": ""}

    # Team members can view all files in their workspace (owner-created and member-created)
    # No visibility restrictions - all members see all files

    with open(file_path, "r", encoding="utf-8") as f:
        return {"content": f.read()}


@app.put("/file/{path:path}")
def save_file(
    path: str, body: FileUpdate, email: str = Query(...), actor: str = Query(None)
):
    email = email.strip().lower()
    actor = (actor or email).strip().lower()
    file_path = safe_path(path, email)

    # Team members can edit all files in their workspace (no permission restrictions)

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(body.content)

    # Track file modification
    versions = load_file_versions()
    file_key = normalize_file_key(os.path.relpath(file_path, BASE_WORKSPACE))
    if file_key not in versions:
        versions[file_key] = {
            "type": "file",
            "created": datetime.now().isoformat(),
            "created_by": actor,
            "versions": [],
        }

    versions[file_key]["modified"] = datetime.now().isoformat()
    versions[file_key]["modified_by"] = actor
    versions[file_key]["versions"].append(
        {
            "timestamp": datetime.now().isoformat(),
            "size": len(body.content),
            "modified_by": actor,
            "content": body.content,  # Store full content for rollback
        }
    )
    save_file_versions(versions)

    # notify workspace members about modification
    try:
        broadcast_msg = {
            "type": "files",
            "action": "modified",
            "path": file_key,
            "actor": actor,
        }
        print(f"Broadcasting modification to workspace {email}: {broadcast_msg}")
        asyncio.create_task(manager.broadcast(email, json.dumps(broadcast_msg)))
    except Exception as e:
        print(f"Error broadcasting modification: {e}")

    return {"ok": True}


# --------------------------------
# TEAM INVITATION ENDPOINTS
# --------------------------------


@app.post("/team/generate-invite-key")
def generate_invite_key(email: str = Query(...)):
    """Generate a unique invitation key for team lead"""
    email = email.strip().lower()
    users = load_users_db()

    if email not in users:
        raise HTTPException(status_code=404, detail="User not found")

    # Generate unique invitation key
    invitation_key = generate_invitation_key()
    teams = load_teams_db()

    if email not in teams:
        teams[email] = {"team_lead": email, "members": [], "invitation_keys": []}

    teams[email]["invitation_keys"].append(
        {"key": invitation_key, "created": datetime.now().isoformat(), "active": True}
    )

    save_teams_db(teams)
    return {
        "ok": True,
        "invitation_key": invitation_key,
        "team_lead": email,
        "message": f"Share this key with team members: {invitation_key}",
    }


@app.post("/team/join-team")
def join_team(request: JoinTeamRequest):
    """Join a team using the invitation key"""
    member_email = request.member_email.strip().lower()
    invitation_key = request.invitation_key.strip().upper()

    users = load_users_db()
    if member_email not in users:
        raise HTTPException(
            status_code=404, detail="Member user not found. Please sign up first."
        )

    teams = load_teams_db()

    # Find team with matching invitation key
    team_lead = None
    for lead_email, team_data in teams.items():
        for key_obj in team_data.get("invitation_keys", []):
            if key_obj["key"] == invitation_key and key_obj["active"]:
                team_lead = lead_email
                break
        if team_lead:
            break

    if not team_lead:
        raise HTTPException(
            status_code=401, detail="Invalid or inactive invitation key"
        )

    # Add member to team if not already present
    if member_email not in teams[team_lead]["members"]:
        teams[team_lead]["members"].append(member_email)
        save_teams_db(teams)

    return {
        "ok": True,
        "team_lead": team_lead,
        "member_email": member_email,
        "message": f"Successfully joined {team_lead}'s team!",
    }


@app.get("/team/info")
def get_team_info(email: str = Query(...)):
    """Get team information for a user"""
    email = email.strip().lower()
    teams = load_teams_db()

    team_data = None
    team_lead = None

    # Check if user is team lead
    if email in teams:
        team_data = teams[email]
        team_lead = email
    else:
        # Check if user is team member
        for lead_email, team in teams.items():
            if email in team.get("members", []):
                team_lead = lead_email
                team_data = team
                break

    if not team_data:
        return {
            "ok": True,
            "is_team_lead": False,
            "team_lead": None,
            "members": [],
            "invitation_keys": [],
        }

    return {
        "ok": True,
        "is_team_lead": (email == team_lead),
        "team_lead": team_lead,
        "members": team_data.get("members", []),
        "invitation_keys": [
            k for k in team_data.get("invitation_keys", []) if k["active"]
        ],
    }


@app.post("/meeting/schedule")
def schedule_meeting(req: MeetingSchedule):
    """Schedule a Google Meet that will notify all workspace members at the scheduled time.

    The request body must include the workspace owner email and desired time.
    The notification will be sent at the scheduled time, not immediately.
    """
    workspace = req.workspace.strip().lower()
    time_str = req.time

    # allow caller to supply a real link; otherwise generate a pseudo-random one
    link = req.link or generate_google_meet_link()

    # store meeting for firing at the right time
    meetings = load_meetings_db()
    meeting_entry = {
        "workspace": workspace,
        "time": time_str,
        "link": link,
        "notified": False,
        "created_at": datetime.now().isoformat(),
    }
    meetings.append(meeting_entry)
    save_meetings_db(meetings)

    print(
        f"[DEBUG] Meeting scheduled: workspace={workspace}, time={time_str}, link={link}"
    )

    # send immediate email + chat notification that meeting was scheduled
    teams = load_teams_db()
    participants = [workspace]
    if workspace in teams:
        participants.extend(teams[workspace].get("members", []))
    participants = list(dict.fromkeys(participants))

    subject = f"Google Meet scheduled for {time_str}"
    body = f"A Google Meet has been scheduled for {time_str}.\n\nJoin here: {link}\n\n--TeamSync"
    for p in participants:
        send_email(p, subject, body)

    # also broadcast to workspace chat immediately so viewers know it was scheduled
    try:
        chat_text = f"📅 Meeting scheduled for {time_str}. Join: {link}"
        asyncio.create_task(manager.broadcast_chat(workspace, "Meeting Bot", chat_text))
    except Exception as e:
        print(f"[DEBUG] error on immediate broadcast: {e}")

    # return link immediately so user can verify
    return {"ok": True, "link": link}


@app.get("/meeting/pending")
def get_pending_meetings(email: str = Query(...)):
    """Return all pending meetings for a workspace (for debugging)."""
    email = email.strip().lower()
    meetings = load_meetings_db()
    pending = [
        m for m in meetings if m.get("workspace") == email and not m.get("notified")
    ]
    return {"workspace": email, "pending_meetings": pending, "total": len(pending)}


@app.post("/file/restore/{path:path}")
def restore_file_version(
    path: str,
    version_index: int = Query(...),
    email: str = Query(...),
    actor: str = Query(None),
):
    """Restore a file to a previous version"""
    email = email.strip().lower()
    actor = (actor or email).strip().lower()
    file_path = safe_path(path, email)

    versions = load_file_versions()
    file_key = normalize_file_key(os.path.relpath(file_path, BASE_WORKSPACE))

    if file_key not in versions:
        raise HTTPException(status_code=404, detail="File not found in version history")

    file_versions = versions[file_key].get("versions", [])

    if version_index < 0 or version_index >= len(file_versions):
        raise HTTPException(status_code=400, detail="Invalid version index")

    # Get the version to restore
    target_version = file_versions[version_index]
    content = target_version.get("content", "")

    # Write the restored content to file
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(content)

    # Add a new version entry for this restoration
    versions[file_key]["modified"] = datetime.now().isoformat()
    versions[file_key]["modified_by"] = actor
    versions[file_key]["versions"].append(
        {
            "timestamp": datetime.now().isoformat(),
            "size": len(content),
            "modified_by": actor,
            "content": content,
            "restored_from": version_index,  # Mark this as a restoration
        }
    )
    save_file_versions(versions)

    # Broadcast the restoration event
    try:
        broadcast_msg = {
            "type": "files",
            "action": "restored",
            "path": file_key,
            "actor": actor,
            "from_version": version_index,
        }
        asyncio.create_task(manager.broadcast(email, json.dumps(broadcast_msg)))
    except Exception as e:
        print(f"Error broadcasting restoration: {e}")

    return {"ok": True, "message": f"Restored to version {version_index}"}


# --------------------------------
# WORKSPACE CODE ENDPOINTS
# --------------------------------


@app.get("/workspace/code")
def get_workspace_code(email: str = Query(...)):
    """Get or create the unique workspace code for a user"""
    email = email.strip().lower()

    # Generate workspace code for any email (don't require user to exist in users_db)
    code = get_or_create_workspace_code(email)

    return {"ok": True, "email": email, "code": code}


@app.post("/workspace/join")
def join_workspace(code: str = Query(...), member_email: str = Query(...)):
    """Join a workspace using the workspace code"""
    code = code.strip().upper()
    member_email = member_email.strip().lower()

    users = load_users_db()
    if member_email not in users:
        raise HTTPException(
            status_code=404, detail="Member user not found. Please sign up first."
        )

    workspace_codes = load_workspace_codes()

    # Find workspace owner with matching code
    workspace_owner = None
    for email, stored_code in workspace_codes.items():
        if stored_code == code:
            workspace_owner = email
            break

    if not workspace_owner:
        raise HTTPException(status_code=401, detail="Invalid workspace code")

    if member_email == workspace_owner:
        raise HTTPException(
            status_code=400, detail="You are already the workspace owner"
        )

    # Add to team if not already
    teams = load_teams_db()
    if workspace_owner not in teams:
        teams[workspace_owner] = {
            "team_lead": workspace_owner,
            "members": [],
            "invitation_keys": [],
        }

    if member_email not in teams[workspace_owner]["members"]:
        teams[workspace_owner]["members"].append(member_email)
        save_teams_db(teams)

    return {
        "ok": True,
        "workspace_owner": workspace_owner,
        "member_email": member_email,
        "message": f"Successfully joined {workspace_owner}'s workspace!",
    }


@app.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket, workspace: str = Query(...), user: str = Query(...)
):
    """WebSocket endpoint for real-time chat and members updates.

    Query params:
      - workspace: workspace owner email (the room)
      - user: connecting user's email
    """
    await manager.connect(workspace, user, websocket)
    try:
        while True:
            data = await websocket.receive_text()
            try:
                payload = json.loads(data)
            except:
                payload = {"text": data}

            # simple chat payload handling
            if isinstance(payload, dict) and payload.get("type") == "chat":
                text = payload.get("text") or ""
                sender = payload.get("sender") or user
                await manager.broadcast_chat(workspace, sender, text)
            else:
                # treat raw string as chat text
                await manager.broadcast_chat(workspace, user, str(payload))

    except WebSocketDisconnect:
        await manager.disconnect(websocket)
        # broadcast updated members after disconnect
        await manager.broadcast_members(workspace)


@app.post("/workspace/leave")
def leave_workspace(workspace: str = Query(...), member_email: str = Query(...)):
    """Remove a member from a workspace's team and return status. Redirect performed on client."""
    workspace = workspace.strip().lower()
    member_email = member_email.strip().lower()

    teams = load_teams_db()
    if workspace not in teams:
        raise HTTPException(status_code=404, detail="Workspace not found")

    if member_email not in teams[workspace].get("members", []):
        return {"ok": True, "message": "Member was not part of workspace"}

    teams[workspace]["members"] = [
        m for m in teams[workspace].get("members", []) if m != member_email
    ]
    save_teams_db(teams)

    # notify via websocket (fire-and-forget)
    try:
        asyncio.create_task(manager.broadcast_members(workspace))
    except Exception:
        pass

    return {"ok": True, "message": f"Left workspace {workspace}"}


# --------------------------------
# PROJECT ENDPOINTS
# --------------------------------


@app.post("/project/create")
def create_project(
    name: str = Query(...),
    deadline: str = Query(...),
    email: str = Query(...),
    actor: str = Query(...),
):
    """Create a new project for a workspace"""
    email = email.strip().lower()
    name = name.strip()

    if not name:
        raise HTTPException(status_code=400, detail="Project name is required")
    if not deadline:
        raise HTTPException(status_code=400, detail="Deadline is required")

    projects = load_projects_db()

    # Use email as workspace key
    if email not in projects:
        projects[email] = []

    # Create project object
    project = {
        "id": len(projects[email]) + 1,
        "name": name,
        "deadline": deadline,
        "created_at": datetime.now().isoformat(),
        "created_by": actor,
    }

    projects[email].append(project)
    save_projects_db(projects)

    # Notify team members via websocket
    try:
        asyncio.create_task(manager.broadcast_projects(email))
    except Exception:
        pass

    return {"ok": True, "message": "Project created successfully", "project": project}


@app.get("/projects")
def get_projects(email: str = Query(...)):
    """Get all projects for a workspace"""
    email = email.strip().lower()

    projects = load_projects_db()
    workspace_projects = projects.get(email, [])

    return {"ok": True, "projects": workspace_projects}


@app.delete("/project/{project_id}")
def delete_project(project_id: int, email: str = Query(...), actor: str = Query(None)):
    """Delete a project. Both owner and team members can delete projects."""
    email = email.strip().lower()
    actor = (actor or email).strip().lower()

    projects = load_projects_db()

    if email not in projects:
        raise HTTPException(status_code=404, detail="Workspace not found")

    projects[email] = [p for p in projects[email] if p.get("id") != project_id]
    save_projects_db(projects)

    # Notify team members via websocket
    try:
        asyncio.create_task(manager.broadcast_projects(email))
    except Exception:
        pass

    return {"ok": True, "message": "Project deleted successfully"}


@app.post("/ai")
async def ai_proxy(request: AIRequest):
    """Proxy an AI prompt to the local Ollama server.

    Accepts messages format: {"messages": [{"role": "user", "content": "hi"}]}
    Or traditional format: {"model": "llama3", "prompt": "your prompt"}
    """
    model = request.model.strip()

    # normalize some common aliases so callers can just say "llama3" or
    # "llama"; the Ollama server generally returns model names like
    # "llama3.2:latest" and will 404 on the shorthand.  If the configured
    # model isn't available later we'll error as before, but mapping the
    # alias prevents the typical 502/404 when using the default value.
    if model.lower() in ("llama3", "llama"):  # allow future aliases
        model = "llama3.2:latest"

    # Handle messages format
    if request.messages:
        # Convert messages format to prompt
        prompt = ""
        for msg in request.messages:
            if msg.get("role") == "user":
                prompt = msg.get("content", "")
                break
    else:
        # Handle traditional prompt format
        prompt = request.prompt or ""

    print(f"[DEBUG] /ai request - model: {model}, prompt: {prompt}")

    OLLAMA_URL = "http://127.0.0.1:11434/api/generate"

    payload = {"model": model, "prompt": prompt, "stream": False}

    try:
        r = requests.post(OLLAMA_URL, json=payload, timeout=60)
    except Exception as e:
        raise HTTPException(
            status_code=502, detail=f"Could not reach Ollama service: {e}"
        )

    if r.status_code != 200:
        raise HTTPException(
            status_code=502, detail=f"Ollama error: {r.status_code} {r.text}"
        )

    try:
        response_data = r.json()
        response_text = response_data.get("response", "No response from AI model")
    except Exception:
        response_text = r.text

    return {"ok": True, "response": response_text}


# Return list of installed Ollama models
@app.get("/ai/models")
def ai_models():
    OLLAMA_TAGS = "http://127.0.0.1:11434/api/tags"
    try:
        r = requests.get(OLLAMA_TAGS, timeout=5)
    except Exception as e:
        raise HTTPException(
            status_code=502, detail=f"Could not reach Ollama service: {e}"
        )

    if r.status_code != 200:
        raise HTTPException(
            status_code=502, detail=f"Ollama error: {r.status_code} {r.text}"
        )

    try:
        data = r.json()
        models = [m.get("name") or m.get("model") for m in data.get("models", [])]
    except Exception:
        models = []

    return {"ok": True, "models": models}


@app.post("/run/python")
async def run_python_file(email: str, file: str):
    """Run a Python file for a user"""
    # Get the workspace path for the user - try multiple locations
    # The backend might be run from different directories
    possible_paths = [
        os.path.join("workspace", email, file),  # Running from perplex-collab/backend
        os.path.join(
            "backend", "workspace", email, file
        ),  # Running from perplex-collab
        os.path.join(
            os.path.dirname(__file__), "workspace", email, file
        ),  # Absolute path
    ]

    print(f"[DEBUG] Looking for file: {file}, email: {email}")
    print(f"[DEBUG] Possible paths: {possible_paths}")

    file_path = None
    for path in possible_paths:
        abs_path = os.path.abspath(path)
        print(f"[DEBUG] Checking: {abs_path}, exists: {os.path.isfile(abs_path)}")
        if os.path.isfile(abs_path):
            file_path = abs_path
            break

    if not file_path:
        # Try to find it in the user folder
        user_folder_candidates = [
            os.path.join("workspace", email),
            os.path.join("backend", "workspace", email),
            os.path.join(os.path.dirname(__file__), "workspace", email),
        ]
        for candidate in user_folder_candidates:
            abs_candidate = os.path.abspath(candidate)
            print(
                f"[DEBUG] Checking directory: {abs_candidate}, exists: {os.path.isdir(abs_candidate)}"
            )
            if os.path.isdir(abs_candidate):
                test_path = os.path.join(abs_candidate, file)
                if os.path.isfile(test_path):
                    file_path = test_path
                    print(f"[DEBUG] Found file: {file_path}")
                    break

    if not file_path or not os.path.isfile(file_path):
        print(f"[DEBUG] File not found, returning error")
        return {"status": "error", "error": f"File not found: {file}"}

    # Check if it's a Python file
    if not file.endswith(".py"):
        return {"status": "error", "error": "Only Python files can be executed"}

    # Run the Python file with absolute path and unbuffered output
    import subprocess

    try:
        print(f"[DEBUG] Executing Python file: {file_path}")
        result = subprocess.run(
            [sys.executable, "-u", file_path],  # -u flag for unbuffered output
            capture_output=True,
            text=True,
            timeout=30,
        )

        print(f"[DEBUG] Subprocess completed with return code: {result.returncode}")
        print(f"[DEBUG] Stdout: {repr(result.stdout)}")
        print(f"[DEBUG] Stderr: {repr(result.stderr)}")

        # Capture both stdout and stderr
        output = result.stdout if result.stdout else ""
        stderr = result.stderr if result.stderr else ""

        # Combine output and error
        full_output = output
        if stderr:
            full_output += f"\n{stderr}"

        # Only show "(no output)" if truly empty
        if not full_output.strip():
            full_output = ""

        print(f"[DEBUG] Final output: {repr(full_output)}")

        return {
            "status": "running",
            "file": file,
            "output": full_output,
            "return_code": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {
            "status": "error",
            "error": "Python execution timed out (max 30 seconds)",
        }
    except Exception as e:
        print(f"[DEBUG] Exception during execution: {str(e)}")
        return {"status": "error", "error": f"Exception: {str(e)}"}


async def check_scheduled_meetings():
    """Background task: every 10 seconds, check if any meetings are due and notify."""
    print("[DEBUG] Background meeting checker task started")
    while True:
        try:
            await asyncio.sleep(10)

            meetings = load_meetings_db()
            now = datetime.now()
            updated = False

            for meeting in meetings:
                if meeting.get("notified"):
                    continue

                try:
                    # parse the meeting time (datetime-local format: "2026-02-25T14:55")
                    meeting_time = datetime.fromisoformat(meeting["time"])
                except Exception as parse_err:
                    print(
                        f"[DEBUG] Failed to parse meeting time '{meeting['time']}': {parse_err}"
                    )
                    continue

                # if meeting time has passed, send notification
                if now >= meeting_time:
                    workspace = meeting["workspace"]
                    link = meeting["link"]
                    time_str = meeting["time"]

                    print(
                        f"[DEBUG] TRIGGERING meeting notification for {workspace} at {now} (meeting was at {meeting_time})"
                    )

                    # send emails to all participants
                    teams = load_teams_db()
                    participants = [workspace]
                    if workspace in teams:
                        participants.extend(teams[workspace].get("members", []))
                    participants = list(dict.fromkeys(participants))

                    print(
                        f"[DEBUG] Sending email to {len(participants)} participants: {participants}"
                    )

                    subject = f"🔔 Your Google Meet is STARTING NOW!"
                    body = f"Your scheduled Google Meet is starting right now!\n\nJoin here: {link}\n\n--TeamSync"
                    for p in participants:
                        result = send_email(p, subject, body)
                        print(f"[DEBUG] Email to {p}: {result}")

                    # broadcast via websocket
                    payload = json.dumps(
                        {
                            "type": "meeting",
                            "workspace": workspace,
                            "time": time_str,
                            "link": link,
                        }
                    )
                    try:
                        loop = asyncio.get_running_loop()
                        await manager.broadcast(workspace, payload)
                        chat_text = f"🔔 MEETING IS STARTING NOW! Join: {link}"
                        await manager.broadcast_chat(
                            workspace, "Meeting Bot", chat_text
                        )
                        print(f"[DEBUG] WebSocket broadcast sent for {workspace}")
                    except Exception as bcast_err:
                        print(
                            f"[DEBUG] error broadcasting meeting at trigger time: {bcast_err}"
                        )

                    meeting["notified"] = True
                    updated = True

            if updated:
                save_meetings_db(meetings)

        except Exception as e:
            print(f"[DEBUG] error in check_scheduled_meetings: {e}")


@app.on_event("startup")
async def startup():
    """Start background tasks on app startup."""
    asyncio.create_task(check_scheduled_meetings())
