from fastapi.testclient import TestClient
import os

import main

client = TestClient(main.app)


def test_schedule_meeting_returns_link_even_without_email():
    # ensure email config is absent so send_email is a no-op
    for var in ["EMAIL_HOST", "EMAIL_PORT", "EMAIL_USER", "EMAIL_PASS"]:
        os.environ.pop(var, None)

    payload = {"workspace": "alice@example.com", "time": "2026-02-25T10:00"}
    response = client.post("/meeting/schedule", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data.get("ok") is True
    assert "link" in data
    assert data["link"].startswith("https://meet.google.com/")
    # scheduling again should still return a link
    response2 = client.post("/meeting/schedule", json=payload)
    assert response2.status_code == 200

    # allow specifying a real meeting link
    custom_link = "https://meet.google.com/abc-def-ghi"
    payload2 = {
        "workspace": "alice@example.com",
        "time": "2026-02-25T11:00",
        "link": custom_link,
    }
    response3 = client.post("/meeting/schedule", json=payload2)
    assert response3.status_code == 200
    assert response3.json().get("link") == custom_link
