try:
    from fastapi import FastAPI, Query, HTTPException
    print("✓ fastapi")
    from fastapi.middleware.cors import CORSMiddleware
    print("✓ CORSMiddleware")
    from pydantic import BaseModel
    print("✓ pydantic")
    import os
    print("✓ os")
    import json
    print("✓ json")
    import requests
    print("✓ requests")
    
    import main
    print("✓ main module imported")
    print("App object:", main.app)
except Exception as e:
    print(f"✗ Error: {e}")
    import traceback
    traceback.print_exc()
