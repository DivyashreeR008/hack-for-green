print("hello world")
print("$$")