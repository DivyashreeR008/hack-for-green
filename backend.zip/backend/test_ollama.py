import requests
import json

OLLAMA_URL = "http://127.0.0.1:11434/api/generate"

payload = {
    "model": "llama3",
    "prompt": "what is 2+2?",
    "stream": False
}

try:
    print("Sending request to Ollama...")
    r = requests.post(OLLAMA_URL, json=payload, timeout=60)
    print(f"Status: {r.status_code}")
    print(f"Raw response: {r.text[:500]}")
    
    if r.status_code == 200:
        data = r.json()
        print(f"Parsed JSON: {json.dumps(data, indent=2)}")
        print(f"Response field: {data.get('response', 'NOT FOUND')}")
except Exception as e:
    print(f"Error: {e}")
